#include<stdio.h>

int main(){
    /* corona */
    printf("Hello World. Lets make a world without corona pox or rabice\n");
    return 0;
}
